-- 1) adiciona a coluna senha, não-nula, com valor default vazio
ALTER TABLE tecnicos
  ADD COLUMN senha VARCHAR(255) NOT NULL DEFAULT '';

-- 2) (opcional) se quiser remover o default após o deploy:
ALTER TABLE tecnicos ALTER COLUMN senha DROP DEFAULT;