INSERT INTO clientes (nome, email, telefone, endereco, data_cadastro)
VALUES ('João da Silva', 'joao@email.com', '11999998888', 'Rua A, 123', CURRENT_TIMESTAMP);

INSERT INTO tecnicos (nome, email, telefone, especialidade, data_contratacao)
VALUES ('Técnico 1', 'tecnico@email.com', '11888887777', 'Máquina de lavar', CURRENT_TIMESTAMP);

INSERT INTO servicos (descricao, categoria, tempo_estimado, valor_estimado)
VALUES ('Manutenção em lavadora', 'Lavadora', 120, 150.00);
