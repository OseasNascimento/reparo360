package br.com.reparo360.controller;

import br.com.reparo360.dto.ServicoDTO;
import br.com.reparo360.service.ServicoService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

        import java.util.List;

/**
 * Controller REST para gerenciamento de serviços
 */
@RestController
@RequestMapping("/api/servicos")
@RequiredArgsConstructor
public class ServicoController {

    private final ServicoService service;

    /**
     * Cria um novo serviço
     * POST /api/servicos
     */
    @PostMapping
    public ResponseEntity<ServicoDTO> create(@RequestBody ServicoDTO dto) {
        ServicoDTO criado = service.create(dto);
        return ResponseEntity.status(HttpStatus.CREATED).body(criado);
    }

    /**
     * Lista todos os serviços
     * GET /api/servicos
     */
    @GetMapping
    public ResponseEntity<List<ServicoDTO>> findAll() {
        List<ServicoDTO> list = service.findAll();
        return ResponseEntity.ok(list);
    }

    /**
     * Busca um serviço pelo ID
     * GET /api/servicos/{id}
     */
    @GetMapping("/{id}")
    public ResponseEntity<ServicoDTO> findById(@PathVariable Long id) {
        ServicoDTO dto = service.findById(id);
        return ResponseEntity.ok(dto);
    }

    /**
     * Atualiza um serviço existente
     * PUT /api/servicos/{id}
     */
    @PutMapping("/{id}")
    public ResponseEntity<ServicoDTO> update(
            @PathVariable Long id,
            @RequestBody ServicoDTO dto) {
        ServicoDTO atualizado = service.update(id, dto);
        return ResponseEntity.ok(atualizado);
    }

    /**
     * Remove um serviço pelo ID
     * DELETE /api/servicos/{id}
     */
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}
