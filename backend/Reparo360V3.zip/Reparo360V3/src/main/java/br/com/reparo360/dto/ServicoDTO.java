package br.com.reparo360.dto;

import lombok.*;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ServicoDTO {
    private Long idServico;

    @NotBlank
    private String descricao;

    private String categoria;

    @DecimalMin("0.0")
    private BigDecimal valorEstimado;

    @Min(1)
    private Integer tempoEstimado;
}