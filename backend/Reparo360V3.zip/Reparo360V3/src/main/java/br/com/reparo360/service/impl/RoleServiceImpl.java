package br.com.reparo360.service.impl;

import br.com.reparo360.dto.RoleDTO;
import br.com.reparo360.model.Role;
import br.com.reparo360.repository.RoleRepository;
import br.com.reparo360.service.RoleService;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class RoleServiceImpl implements RoleService {

    private final RoleRepository repo;

    private RoleDTO toDTO(Role r) {
        return RoleDTO.builder()
                .idRole(r.getId())           // usa getIdRole()
                .nomeRole(r.getNomeRole())       // usa getNomeRole()
                .descricao(r.getDescricao())     // usa getDescricao()
                .build();
    }

    @Override
    public RoleDTO create(RoleDTO dto) {
        // mapeamento manual do DTO para a entidade
        Role r = new Role();
        r.setNomeRole(dto.getNomeRole());
        r.setDescricao(dto.getDescricao());

        Role salvo = repo.save(r);
        return toDTO(salvo);
    }

    @Override
    public List<RoleDTO> findAll() {
        return repo.findAll()
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    public RoleDTO findById(Long id) {
        Role r = repo.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Role não encontrada"));
        return toDTO(r);
    }

    @Override
    public RoleDTO update(Long id, RoleDTO dto) {
        Role r = repo.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Role não encontrada"));

        // aplica alterações
        r.setNomeRole(dto.getNomeRole());
        r.setDescricao(dto.getDescricao());

        Role atualizado = repo.save(r);
        return toDTO(atualizado);
    }

    @Override
    public void delete(Long id) {
        if (!repo.existsById(id)) {
            throw new EntityNotFoundException("Role não encontrada");
        }
        repo.deleteById(id);
    }
}
