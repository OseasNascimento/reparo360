package br.com.reparo360.controller;

import br.com.reparo360.dto.AgendamentoDTO;
import br.com.reparo360.model.StatusAgendamento;
import br.com.reparo360.service.AgendamentoService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/agendamentos")
@RequiredArgsConstructor
public class AgendamentoController {
    private final AgendamentoService service;

    @PostMapping
    public ResponseEntity<AgendamentoDTO> create(@RequestBody AgendamentoDTO dto) {
        AgendamentoDTO criado = service.create(dto);
        return ResponseEntity.status(HttpStatus.CREATED).body(criado);
    }

    @GetMapping
    public ResponseEntity<List<AgendamentoDTO>> findAll(
            @RequestParam(required = false) Long tecnicoId) {

        List<AgendamentoDTO> list;
        if (tecnicoId != null) {
            // chama historyByTecnico corretamente
            list = service.historyByTecnico(tecnicoId);
        } else {
            list = service.findAll();
        }
        return ResponseEntity.ok(list);
    }

    @GetMapping("/{id}")
    public ResponseEntity<AgendamentoDTO> findById(@PathVariable Long id) {
        return ResponseEntity.ok(service.findById(id));
    }

    /**
     * PATCH /api/agendamentos/{id}/status?novoStatus=EM_ANDAMENTO
     * Recebe o enum StatusAgendamento e converte para String para o service
     */
    @PatchMapping("/{id}/status")
    public ResponseEntity<AgendamentoDTO> updateStatus(
            @PathVariable Long id,
            @RequestParam("novoStatus") StatusAgendamento status) {

        // converte enum para String antes de chamar o service
        AgendamentoDTO dto = service.updateStatus(id, status.name());
        return ResponseEntity.ok(dto);
    }

    /**
     * PATCH /api/agendamentos/{id}/cancelar
     * Cancela o agendamento diretamente
     */
    @PatchMapping("/{id}/cancelar")
    public ResponseEntity<AgendamentoDTO> cancel(@PathVariable Long id) {
        AgendamentoDTO dto = service.updateStatus(id, StatusAgendamento.CANCELADO.name());
        return ResponseEntity.ok(dto);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }

    @GetMapping("/cliente/{clienteId}")
    public ResponseEntity<List<AgendamentoDTO>> historyByCliente(
            @PathVariable Long clienteId) {

        return ResponseEntity.ok(service.historyByCliente(clienteId));
    }

    @GetMapping("/tecnico/{tecnicoId}")
    public ResponseEntity<List<AgendamentoDTO>> historyByTecnico(
            @PathVariable Long tecnicoId) {

        return ResponseEntity.ok(service.historyByTecnico(tecnicoId));
    }
}
