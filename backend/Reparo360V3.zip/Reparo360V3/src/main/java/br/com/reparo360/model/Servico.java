package br.com.reparo360.model;

import lombok.*;
import jakarta.persistence.*;
import java.math.BigDecimal;

@Entity
@Table(name = "servicos")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Servico {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idServico;
    private String descricao;
    private String categoria;
    private BigDecimal valorEstimado;
    private Integer tempoEstimado;
}