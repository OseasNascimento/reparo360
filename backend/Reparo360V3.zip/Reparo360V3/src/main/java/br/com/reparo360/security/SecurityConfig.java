package br.com.reparo360.security;

import br.com.reparo360.security.JwtFilter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.List;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfig {

    private final JwtFilter jwtFilter;
    private final UserDetailsServiceImpl userDetailsService;

    public SecurityConfig(JwtFilter jwtFilter,
                          UserDetailsServiceImpl userDetailsService) {
        this.jwtFilter = jwtFilter;
        this.userDetailsService = userDetailsService;
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
                .cors(Customizer.withDefaults())
                .csrf(csrf -> csrf.disable())
                .sessionManagement(sm ->
                        sm.sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                )
                .authorizeHttpRequests(auth -> auth
                        // H2 console
                        .requestMatchers("/h2-console/**").permitAll()

                        .requestMatchers(HttpMethod.POST, "/api/auth/login").permitAll()

                        // Bootstrap inicial (uma única vez) – aqui você pode migrar para /api/bootstrap caso queira
                        .requestMatchers(HttpMethod.POST, "/api/tecnicos").permitAll()

                        // Fluxo anônimo de agendamento
                        .requestMatchers(HttpMethod.GET,  "/api/tecnicos").permitAll()
                        .requestMatchers(HttpMethod.GET,  "/api/servicos").permitAll()
                        .requestMatchers(HttpMethod.POST, "/api/clientes").permitAll()
                        .requestMatchers(HttpMethod.POST, "/api/agendamentos").permitAll()
                        .requestMatchers(HttpMethod.GET,  "/api/agendamentos/*").permitAll()

                        // Listagem de todos os agendamentos – agora ADMIN também consegue
                        .requestMatchers(HttpMethod.GET, "/api/agendamentos")
                        .hasAnyRole("TECNICO","ADMIN")

                        // Avançar status – só TÉCNICO
                        .requestMatchers(HttpMethod.PATCH, "/api/agendamentos/**/status")
                        .hasRole("TECNICO")

                        // CRUD de Serviços – só ADMIN
                        .requestMatchers(HttpMethod.POST,   "/api/servicos").hasRole("ADMIN")
                        .requestMatchers(HttpMethod.PUT,    "/api/servicos/**").hasRole("ADMIN")
                        .requestMatchers(HttpMethod.DELETE, "/api/servicos/**").hasRole("ADMIN")

                        // CRUD de Técnicos (exceto bootstrap) – só ADMIN
                        .requestMatchers(HttpMethod.PUT,    "/api/tecnicos/**").hasRole("ADMIN")
                        .requestMatchers(HttpMethod.DELETE, "/api/tecnicos/**").hasRole("ADMIN")
                        .requestMatchers(HttpMethod.GET,    "/api/tecnicos/**").hasRole("ADMIN")
                        // se quiser bloquear novos POSTs de técnicos após o bootstrap:
                        //.requestMatchers(HttpMethod.POST,   "/api/tecnicos").hasRole("ADMIN")

                        // Qualquer outra rota exige autenticação
                        .anyRequest().authenticated()
                )
                // UserDetailsService + PasswordEncoder
                .authenticationProvider(authenticationProvider())
                // Filtro JWT
                .addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class)
                // H2 em iframe
                .headers(headers -> headers.frameOptions(f -> f.disable()))
        ;
        return http.build();
    }


    @Bean
    public AuthenticationManager authenticationManager(
            AuthenticationConfiguration authConfig
    ) throws Exception {
        return authConfig.getAuthenticationManager();
    }

    @Bean
    public DaoAuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
        provider.setUserDetailsService(userDetailsService);
        provider.setPasswordEncoder(passwordEncoder());
        return provider;
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    /**
     * CorsConfigurationSource para liberar chamadas do front em http://localhost:3000
     */
    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration config = new CorsConfiguration();
        config.setAllowedOrigins(List.of("http://localhost:3000"));
        config.setAllowedMethods(List.of("GET","POST","PUT","DELETE","PATCH","OPTIONS"));
        config.setAllowedHeaders(List.of("*"));
        config.setAllowCredentials(true);

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", config);
        return source;
    }
}
