package br.com.reparo360.model;

// no seu enum StatusAgendamento
public enum StatusAgendamento {
    AGENDADO,
    TECNICO_A_CAMINHO,
    TECNICO_CHEGOU,
    EM_ANDAMENTO,
    CANCELADO,
    CONCLUIDO;
}
