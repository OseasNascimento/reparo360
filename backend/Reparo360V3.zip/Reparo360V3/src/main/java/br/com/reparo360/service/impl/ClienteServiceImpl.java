package br.com.reparo360.service.impl;

import br.com.reparo360.dto.ClienteDTO;
import br.com.reparo360.model.Cliente;
import br.com.reparo360.repository.ClienteRepository;
import br.com.reparo360.service.ClienteService;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ClienteServiceImpl implements ClienteService {

    private final ClienteRepository repo;

    private ClienteDTO toDTO(Cliente c) {
        return ClienteDTO.builder()
                .idCliente(c.getIdCliente())
                .nome(c.getNome())
                .email(c.getEmail())
                .telefone(c.getTelefone())
                .endereco(c.getEndereco())
                .dataCadastro(c.getDataCadastro())
                .build();
    }

    @Override
    public ClienteDTO create(ClienteDTO dto) {
        // mapeamento manual de DTO para entidade
        Cliente c = new Cliente();
        c.setNome(dto.getNome());
        c.setEmail(dto.getEmail());
        c.setTelefone(dto.getTelefone());
        c.setEndereco(dto.getEndereco());
        c.setDataCadastro(dto.getDataCadastro());

        Cliente salvo = repo.save(c);
        return toDTO(salvo);
    }

    @Override
    public List<ClienteDTO> findAll() {
        return repo.findAll()
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    public ClienteDTO findById(Long id) {
        Cliente c = repo.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Cliente não encontrado"));
        return toDTO(c);
    }

    @Override
    public ClienteDTO update(Long id, ClienteDTO dto) {
        Cliente c = repo.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Cliente não encontrado"));

        // aplica alterações
        c.setNome(dto.getNome());
        c.setEmail(dto.getEmail());
        c.setTelefone(dto.getTelefone());
        c.setEndereco(dto.getEndereco());
        // se quiser permitir alterar a data de cadastro, descomente:
        // c.setDataCadastro(dto.getDataCadastro());

        Cliente atualizado = repo.save(c);
        return toDTO(atualizado);
    }

    @Override
    public void delete(Long id) {
        if (!repo.existsById(id)) {
            throw new EntityNotFoundException("Cliente não encontrado");
        }
        repo.deleteById(id);
    }
}
