package br.com.reparo360.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder

public class RoleDTO {
    private Long idRole;      // agora bate com .idRole(...)
    private String nomeRole;
    private String descricao;
}

