package br.com.reparo360.controller;
import org.springframework.http.*;
        import org.springframework.web.bind.annotation.*;
        import java.util.Map;

@RestControllerAdvice
public class ControllerAdvice {

    @ExceptionHandler(RuntimeException.class)
    public ResponseEntity<Map<String, String>> handleBusiness(RuntimeException ex) {
        // você pode filtrar aqui por mensagem ou tipo de exception
        return ResponseEntity
                .status(HttpStatus.CONFLICT)
                .body(Map.of("error", ex.getMessage()));
    }

    // você pode adicionar @ExceptionHandler para outras exceções específicas
}
