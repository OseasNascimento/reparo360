package br.com.reparo360.repository;

import br.com.reparo360.model.Agendamento;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface AgendamentoRepository extends JpaRepository<Agendamento, Long> {
    List<Agendamento> findAllByTecnico_IdTecnico(Long idTecnico);
    List<Agendamento> findAllByCliente_IdCliente(Long idCliente);
}