package br.com.reparo360.security;

import br.com.reparo360.model.Tecnico;
import br.com.reparo360.repository.TecnicoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.*;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class UserDetailsServiceImpl implements UserDetailsService {

    private final TecnicoRepository repo;

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        Tecnico tec = repo.findByEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException("Técnico não encontrado: " + email));

        // Converte as roles da entidade em GrantedAuthority
        List<GrantedAuthority> authorities = tec.getRoles().stream()
                .map(role -> new SimpleGrantedAuthority(role.getNomeRole()))
                .collect(Collectors.toList());

        // Monta o UserDetails com as authorities dinâmicas
        return User.builder()
                .username(tec.getEmail())
                .password(tec.getSenha())       // hash BCrypt salvo no banco
                .authorities(authorities)       // usa as roles reais do banco
                .build();
    }
}
