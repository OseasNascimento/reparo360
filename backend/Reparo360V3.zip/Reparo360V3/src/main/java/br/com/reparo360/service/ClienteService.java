package br.com.reparo360.service;

import br.com.reparo360.dto.ClienteDTO;
import java.util.List;

public interface ClienteService {
    ClienteDTO create(ClienteDTO dto);
    List<ClienteDTO> findAll();
    ClienteDTO findById(Long id);
    ClienteDTO update(Long id, ClienteDTO dto);
    void delete(Long id);
}