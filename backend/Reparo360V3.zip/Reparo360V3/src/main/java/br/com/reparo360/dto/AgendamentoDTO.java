package br.com.reparo360.dto;

import br.com.reparo360.model.StatusAgendamento;
import lombok.*;
import jakarta.validation.constraints.*;
import java.time.LocalDateTime;
import java.util.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AgendamentoDTO {
    private Long idAgendamento;

    @NotNull
    private Long idCliente;

    @NotNull
    private Long idTecnico;

    @NotEmpty
    private Set<Long> idServicos;

    @NotNull
    private LocalDateTime dataAgendamento;

    private StatusAgendamento status;
    private String observacoes;
}