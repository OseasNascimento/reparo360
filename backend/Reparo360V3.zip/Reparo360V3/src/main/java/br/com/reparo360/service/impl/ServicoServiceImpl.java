package br.com.reparo360.service.impl;

import br.com.reparo360.dto.ServicoDTO;
import br.com.reparo360.model.Servico;
import br.com.reparo360.repository.ServicoRepository;
import br.com.reparo360.service.ServicoService;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ServicoServiceImpl implements ServicoService {

    private final ServicoRepository repo;

    private ServicoDTO toDTO(Servico s) {
        return ServicoDTO.builder()
                .idServico(s.getIdServico())           // mesmo nome do campo no DTO
                .descricao(s.getDescricao())
                .valorEstimado(s.getValorEstimado())
                .tempoEstimado(s.getTempoEstimado())
                .build();
    }

    @Override
    public ServicoDTO create(ServicoDTO dto) {
        // mapeamento manual do DTO para a entidade
        Servico s = new Servico();
        s.setDescricao(dto.getDescricao());
        s.setValorEstimado(dto.getValorEstimado());
        s.setTempoEstimado(dto.getTempoEstimado());

        Servico salvo = repo.save(s);
        return toDTO(salvo);
    }

    @Override
    public List<ServicoDTO> findAll() {
        return repo.findAll()
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    public ServicoDTO findById(Long id) {
        Servico s = repo.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Serviço não encontrado"));
        return toDTO(s);
    }

    @Override
    public ServicoDTO update(Long id, ServicoDTO dto) {
        Servico s = repo.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Serviço não encontrado"));
        // aplica as mudanças
        s.setDescricao(dto.getDescricao());
        s.setValorEstimado(dto.getValorEstimado());
        s.setTempoEstimado(dto.getTempoEstimado());

        Servico atualizado = repo.save(s);
        return toDTO(atualizado);
    }

    @Override
    public void delete(Long id) {
        if (!repo.existsById(id)) {
            throw new EntityNotFoundException("Serviço não encontrado");
        }
        repo.deleteById(id);
    }
}
