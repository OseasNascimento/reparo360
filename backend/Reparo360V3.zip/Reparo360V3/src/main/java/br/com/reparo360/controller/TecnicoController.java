package br.com.reparo360.controller;

import br.com.reparo360.dto.TecnicoDTO;
import br.com.reparo360.service.TecnicoService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

        import java.util.List;

/**
 * Controller REST para gerenciamento de técnicos
 */
@RestController
@RequestMapping("/api/tecnicos")
@RequiredArgsConstructor
public class TecnicoController {

    private final TecnicoService service;

    /**
     * Cria um novo técnico
     * POST /api/tecnicos
     */
    @PostMapping
    public ResponseEntity<TecnicoDTO> create(@RequestBody TecnicoDTO dto) {
        TecnicoDTO criado = service.create(dto);
        return ResponseEntity.status(HttpStatus.CREATED).body(criado);
    }

    /**
     * Lista todos os técnicos
     * GET /api/tecnicos
     */
    @GetMapping
    public ResponseEntity<List<TecnicoDTO>> findAll() {
        List<TecnicoDTO> list = service.findAll();
        return ResponseEntity.ok(list);
    }

    /**
     * Busca um técnico pelo ID
     * GET /api/tecnicos/{id}
     */
    @GetMapping("/{id}")
    public ResponseEntity<TecnicoDTO> findById(@PathVariable Long id) {
        TecnicoDTO dto = service.findById(id);
        return ResponseEntity.ok(dto);
    }

    /**
     * Atualiza um técnico existente
     * PUT /api/tecnicos/{id}
     */
    @PutMapping("/{id}")
    public ResponseEntity<TecnicoDTO> update(
            @PathVariable Long id,
            @RequestBody TecnicoDTO dto) {
        TecnicoDTO atualizado = service.update(id, dto);
        return ResponseEntity.ok(atualizado);
    }

    /**
     * Remove um técnico pelo ID
     * DELETE /api/tecnicos/{id}
     */
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}
