package br.com.reparo360.repository;

import br.com.reparo360.model.Tecnico;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface TecnicoRepository extends JpaRepository<Tecnico, Long> {
    /**
     * Busca um técnico pelo e-mail **trazendo também as roles**.
     */
    @EntityGraph(attributePaths = "roles")
    Optional<Tecnico> findByEmail(String email);
}
