package br.com.reparo360.service.impl;

import br.com.reparo360.dto.RoleDTO;
import br.com.reparo360.dto.TecnicoDTO;
import br.com.reparo360.model.Role;
import br.com.reparo360.model.Tecnico;
import br.com.reparo360.repository.RoleRepository;
import br.com.reparo360.repository.TecnicoRepository;
import br.com.reparo360.service.TecnicoService;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class TecnicoServiceImpl implements TecnicoService {
    private final TecnicoRepository repo;
    private final PasswordEncoder passwordEncoder;
    private final RoleRepository roleRepo;

    private TecnicoDTO toDTO(Tecnico tec) {
        Set<RoleDTO> rolesDto = tec.getRoles()
                .stream()
                .map(r -> RoleDTO.builder()
                        .idRole(r.getId())
                        .nomeRole(r.getNomeRole())
                        .descricao(r.getDescricao())
                        .build())
                .collect(Collectors.toSet());

        return TecnicoDTO.builder()
                .idTecnico(tec.getIdTecnico())
                .nome(tec.getNome())
                .especialidade(tec.getEspecialidade())
                .telefone(tec.getTelefone())
                .email(tec.getEmail())
                .dataContratacao(tec.getDataContratacao())
                .roles(rolesDto)
                .build();
    }

    @Override
    public TecnicoDTO create(TecnicoDTO dto) {
        Tecnico tec = new Tecnico();
        tec.setNome(dto.getNome());
        tec.setEspecialidade(dto.getEspecialidade());
        tec.setTelefone(dto.getTelefone());
        tec.setEmail(dto.getEmail());
        tec.setDataContratacao(dto.getDataContratacao());
        tec.setSenha(passwordEncoder.encode(dto.getSenha()));

        // Atribuir ROLE_TECNICO por padrão
        Role roleTec = roleRepo.findByNomeRole("ROLE_TECNICO")
                .orElseThrow(() -> new EntityNotFoundException("Role ROLE_TECNICO não encontrada"));
        tec.setRoles(Set.of(roleTec));

        Tecnico salvo = repo.save(tec);
        return toDTO(salvo);
    }

    @Override
    public List<TecnicoDTO> findAll() {
        return repo.findAll()
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    public TecnicoDTO findById(Long id) {
        Tecnico tec = repo.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Técnico não encontrado"));
        return toDTO(tec);
    }

    @Override
    public TecnicoDTO update(Long id, TecnicoDTO dto) {
        Tecnico tec = repo.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Técnico não encontrado"));

        tec.setNome(dto.getNome());
        tec.setEspecialidade(dto.getEspecialidade());
        tec.setTelefone(dto.getTelefone());
        tec.setEmail(dto.getEmail());
        if (dto.getSenha() != null) {
            tec.setSenha(passwordEncoder.encode(dto.getSenha()));
        }
        if (dto.getRoles() != null) {
            Set<Role> novas = dto.getRoles()
                    .stream()
                    .map(rdto -> roleRepo.findByNomeRole(rdto.getNomeRole())
                            .orElseThrow(() -> new EntityNotFoundException("Role não encontrada: " + rdto.getNomeRole())))
                    .collect(Collectors.toSet());
            tec.setRoles(novas);
        }

        Tecnico atualizado = repo.save(tec);
        return toDTO(atualizado);
    }

    @Override
    public void delete(Long id) {
        if (!repo.existsById(id)) {
            throw new EntityNotFoundException("Técnico não encontrado");
        }
        repo.deleteById(id);
    }
}

