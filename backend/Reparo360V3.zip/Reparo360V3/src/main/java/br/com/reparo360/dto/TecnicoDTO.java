package br.com.reparo360.dto;

import lombok.*;
import jakarta.validation.constraints.*;
import java.time.LocalDateTime;
import java.util.Set;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TecnicoDTO {
    private Long idTecnico;

    @NotBlank
    private String nome;

    private String especialidade;

    private String telefone;

    @Email
    private String email;

    private LocalDateTime dataContratacao;

    private String senha;

    // Lista de roles representadas como DTOs
    private Set<RoleDTO> roles;
}