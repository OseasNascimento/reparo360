package br.com.reparo360.security;

import br.com.reparo360.model.Tecnico;
import br.com.reparo360.repository.TecnicoRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthenticationManager authManager;
    private final JwtUtil jwtUtil;
    private final TecnicoRepository tecnicoRepo;

    public AuthController(
            AuthenticationManager authManager,
            JwtUtil jwtUtil,
            TecnicoRepository tecnicoRepo
    ) {
        this.authManager = authManager;
        this.jwtUtil = jwtUtil;
        this.tecnicoRepo = tecnicoRepo;
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String, String> creds) {
        String email = creds.get("email");
        String senha = creds.get("senha");

        try {
            // executa a autenticação e obtém o Authentication completo
            Authentication authentication = authManager.authenticate(
                    new UsernamePasswordAuthenticationToken(email, senha)
            );

            // gera o JWT incluindo as roles
            String token = jwtUtil.generateToken(authentication);

            // busca o id do técnico para devolver ao front
            Tecnico tec = tecnicoRepo.findByEmail(authentication.getName())
                    .orElseThrow(() -> new RuntimeException("Técnico não encontrado"));
            Long tecnicoId = tec.getIdTecnico();

            // retorna { token, tecnicoId }
            return ResponseEntity.ok(Map.of(
                    "token",     token,
                    "tecnicoId", tecnicoId
            ));

        } catch (AuthenticationException ex) {
            // credenciais inválidas
            return ResponseEntity
                    .status(401)
                    .body(Map.of("error", "Credenciais inválidas"));
        }
    }
}
