package br.com.reparo360.dto;

import lombok.*;
import jakarta.validation.constraints.*;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ClienteDTO {
    private Long idCliente;

    @NotBlank
    private String nome;

    private String telefone;

    @Email
    private String email;

    private String endereco;
    private LocalDateTime dataCadastro;
}