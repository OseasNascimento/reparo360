package br.com.reparo360.service.impl;

import br.com.reparo360.dto.AgendamentoDTO;
import br.com.reparo360.model.Agendamento;
import br.com.reparo360.model.Servico;
import br.com.reparo360.model.StatusAgendamento;
import br.com.reparo360.model.Cliente;
import br.com.reparo360.model.Tecnico;
import br.com.reparo360.repository.AgendamentoRepository;
import br.com.reparo360.repository.ClienteRepository;
import br.com.reparo360.repository.TecnicoRepository;
import br.com.reparo360.repository.ServicoRepository;
import br.com.reparo360.service.AgendamentoService;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AgendamentoServiceImpl implements AgendamentoService {
    private final AgendamentoRepository agendamentoRepo;
    private final ClienteRepository clienteRepo;
    private final TecnicoRepository tecnicoRepo;
    private final ServicoRepository servicoRepo;

    private AgendamentoDTO toDTO(Agendamento a) {
        return AgendamentoDTO.builder()
                .idAgendamento(a.getIdAgendamento())
                .idCliente(a.getCliente().getIdCliente())
                .idTecnico(a.getTecnico().getIdTecnico())
                .idServicos(a.getServicos()
                        .stream()
                        .map(Servico::getIdServico)
                        .collect(Collectors.toSet()))
                .dataAgendamento(a.getDataAgendamento())
                .status(a.getStatus())
                .observacoes(a.getObservacoes())
                .build();
    }

    @Override
    public AgendamentoDTO create(AgendamentoDTO dto) {
        Agendamento a = new Agendamento();

        Cliente cliente = clienteRepo.findById(dto.getIdCliente())
                .orElseThrow(() -> new EntityNotFoundException("Cliente não encontrado"));
        a.setCliente(cliente);

        Tecnico tecnico = tecnicoRepo.findById(dto.getIdTecnico())
                .orElseThrow(() -> new EntityNotFoundException("Técnico não encontrado"));
        a.setTecnico(tecnico);

        a.setDataAgendamento(dto.getDataAgendamento());
        a.setObservacoes(dto.getObservacoes());
        a.setStatus(StatusAgendamento.AGENDADO);

        Set<Servico> servicos = dto.getIdServicos().stream()
                .map(id -> servicoRepo.findById(id)
                        .orElseThrow(() -> new EntityNotFoundException("Serviço não encontrado: " + id)))
                .collect(Collectors.toSet());
        a.setServicos(servicos);

        Agendamento salvo = agendamentoRepo.save(a);
        return toDTO(salvo);
    }

    @Override
    public List<AgendamentoDTO> findAll() {
        return agendamentoRepo.findAll()
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    public AgendamentoDTO findById(Long id) {
        Agendamento a = agendamentoRepo.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Agendamento não encontrado"));
        return toDTO(a);
    }

    @Override
    public AgendamentoDTO updateStatus(Long id, String novoStatus) {
        Agendamento a = agendamentoRepo.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Agendamento não encontrado"));
        a.setStatus(StatusAgendamento.valueOf(novoStatus));
        Agendamento atualizado = agendamentoRepo.save(a);
        return toDTO(atualizado);
    }

    @Override
    public void delete(Long id) {
        if (!agendamentoRepo.existsById(id)) {
            throw new EntityNotFoundException("Agendamento não encontrado");
        }
        agendamentoRepo.deleteById(id);
    }

    @Override
    public List<AgendamentoDTO> historyByCliente(Long clienteId) {
        return agendamentoRepo.findAllByCliente_IdCliente(clienteId)
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<AgendamentoDTO> historyByTecnico(Long tecnicoId) {
        return agendamentoRepo.findAllByTecnico_IdTecnico(tecnicoId)
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }
}