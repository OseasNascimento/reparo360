package br.com.reparo360.service;

import br.com.reparo360.dto.AgendamentoDTO;
import java.util.List;

public interface AgendamentoService {
    AgendamentoDTO create(AgendamentoDTO dto);
    List<AgendamentoDTO> findAll();
    AgendamentoDTO findById(Long id);
    AgendamentoDTO updateStatus(Long id, String novoStatus);
    void delete(Long id);
    List<AgendamentoDTO> historyByCliente(Long clienteId);
    List<AgendamentoDTO> historyByTecnico(Long tecnicoId);
}
