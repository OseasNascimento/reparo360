package br.com.reparo360.model;

import lombok.*;
import jakarta.persistence.*;
import java.util.Set;

@Entity
@Table(name = "roles")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder

public class Role {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_ROLE")
    private Long id;

    @Column(name = "nome_role", nullable = false, unique = true)
    private String nomeRole;

    private String descricao;

    @ManyToMany(mappedBy = "roles")
    private Set<Tecnico> tecnicos;
}